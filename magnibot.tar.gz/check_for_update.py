import subprocess
import requests
import os.path
import json
import JSONLib

class UpdaterLib(object):
    def __init__(self):
        self.debug = False
        self.internt_on = False
        self.commit_id = ""
        self.latest_tag = ""
        self.current_tag = ""
        self.version_json=None
        print("UpdaterLib: Initialized")
    def internet_on(self):
        try:
            request = requests.get("https://github.com/", timeout=2)
            return True
        except (requests.ConnectionError, requests.Timeout) as exception:
            return False
        
    
    def get_current_tag(self):
        settings=JSONLib.JSONLib()
        return settings.get_version_code()
    def get_file_size(self):
        if self.version_json!=None:
            return self.version_json['file_size_bytes']
        else:
            return None
    def check_for_update(self):
        if self.internet_on()==False:
            return True
        json_file='version.json'
        subprocess.Popen(['rm','-rf','version.json.*'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subprocess.Popen(['rm',json_file],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        process = subprocess.Popen(['wget','https://raw.githubusercontent.com/trysightdev/magnibot_releases/main/version.json'],stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = process.communicate()
        out = out.decode("utf-8")
        err = err.decode("utf-8")
        print("", out, err)
        self.version_json=None
        with open( json_file, 'r') as f:
            self.version_json = json.load(f)

        f.close()
        latest=float(self.version_json['version_code'])
        current=float(self.get_current_tag())
        print("current: ",current)
        print("latest: ",latest)
        if current<latest:
            return False
        else:
            return True

print("hello v2")

# tmpUpdater=UpdaterLib()

# if( tmpUpdater.internet_on() ):
#     print("",tmpUpdater.get_commit_id())
#     print("",tmpUpdater.get_latest_tag())
#     print("",tmpUpdater.get_current_tag())
#     print("",tmpUpdater.check_for_update())
# else:
#     print("",tmpUpdater.get_current_tag())
#     print("No internet")

