# Picamera2-streamer
## Install Streamer
```
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-venv git
git clone https://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@github.com/trysightdev/magnibot-pistreamer.git
cd magnibot-pistreamer
python3 -m venv venv --system-site-packages
```

## Additional Info
### Check CPU Usage
```
watch -n1 vcgencmd measure_clock arm
```

## Dependencies
* [PiCamera2](https://github.com/raspberrypi/picamera2/tree/v0.3.12)
* [LibCamera](https://github.com/raspberrypi/libcamera/tree/5ff5efbdc35dc61873b950326ca6798c44a37686)
* [RPi Gadget Mode](https://github.com/trysightdev/rpi-usb-gadget)


## Research
* Tried using OpenCV to resize image and add black borders but this caused alot of lag
