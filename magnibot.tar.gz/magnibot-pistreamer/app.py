#!/usr/bin/python3
# Mostly copied from https://picamera.readthedocs.io/en/release-1.13/recipes2.html
# Run this script, then point a web browser at http:<this-ip-address>:8000
# Note: needs simplejpeg to be installed (pip3 install simplejpeg).
import io
import logging
import socketserver
import time
import json
import urllib.request
from http import server
from threading import Condition
from picamera2 import Picamera2
from picamera2.encoders import MJPEGEncoder
from picamera2.encoders import JpegEncoder
from picamera2.encoders import Encoder
from picamera2.outputs import FileOutput
from libcamera import controls
from libcamera import ColorSpace
from enum import Enum
import subprocess
import os
import cv2
import numpy as np
import random
import struct

ZOOM_IN = 0.977
ZOOM_OUT = 1.033
OCR_PATH = "~/raspberrypi-ocr/ocr/"
isCSICameraAttached = False

class ZoomMode(Enum):
    ZoomIn = 1
    ZoomOut = 2
    ZoomStop = 3
class PanMode(Enum):
    Up = 1
    Left = 2
    Right = 3
    Down = 4
    Stop = 5
class StreamingOutput(io.BufferedIOBase):
    def __init__(self, p_picam = None):
        print("New output")
        self.streaming = False
        self.picam2 = p_picam
        self.frame = None
        self.condition = Condition()
        self.frame_count = 0
        self.zoom_mode = ZoomMode.ZoomStop
        self.lastDraw = time.time()
        self.size = None
        self.full_res = None
        self.scalerCropMaximum = None
        self.offset = [0.5, 0.5]
        self.panDelta = [0,0]
        self.oldZoomScale = 1
        self.oldScalerCrop = []
        self.zoomScale = 1
        self.writtenZoom = 1
        self.scalerCrop = []
        self.scalerCropUpdate = True
        self.zoomState = "zoomedIn"
        self.zoomAmount = 0.35
        self.currentSize = None
        self.flipped = False
        self.settings = None

    def setZoom(self,zoom_mode):
        self.zoom_mode = zoom_mode

    def setPan(self,pan):
        self.panDelta = [pan[0] * 0.006, pan[1] * 0.006]


    def updateScalerCrop(self):
        self.currentSize = newSize = [(s * self.zoomScale) for s in self.size]
                
        boundingSize = (newSize[0]/self.scalerCropMaximum[2])/2

        self.offset[0] = min(1-boundingSize, max(boundingSize, self.offset[0]+(self.panDelta[0]*3.6)))
        self.offset[1] = min(1-boundingSize, max(boundingSize, self.offset[1]+self.panDelta[1]))
        newOffset = [(self.scalerCropMaximum[2] - newSize[0]) * self.offset[1], (self.scalerCropMaximum[3] - newSize[1]) * self.offset[0]]

        self.scalerCrop = [int(x) for x in (newOffset+newSize)]
        self.picam2.set_controls({"ScalerCrop": self.scalerCrop})
        self.scalerCropUpdate = False


    def write(self, buf):
        if(self.scalerCropMaximum == None):
            self.scalerCropMaximum = self.picam2.camera_properties['ScalerCropMaximum']

        if(self.size == None):
            self.size = self.picam2.capture_metadata()['ScalerCrop'][2:]
            self.size = [int(s * 1.00) for s in self.size]
            self.scalerCrop = [int(x) for x in (self.offset+self.size)]

        if(self.full_res == None):
            self.full_res = self.picam2.camera_properties['PixelArraySize']

        with self.condition:
            deltaTime = time.time() - self.lastDraw

            self.frame = buf
            self.frame_count += 1
            self.condition.notify_all()

            if self.zoomScale > 1:
                self.zoomAmount = 0.45
            else:
                self.zoomAmount = 0.35
            if self.zoom_mode==ZoomMode.ZoomIn:
                self.zoomScale = max(self.zoomScale - (self.zoomAmount * deltaTime), 0.1)
            elif self.zoom_mode==ZoomMode.ZoomOut:
                self.zoomScale = min(self.zoomScale + (self.zoomAmount * deltaTime), 3.15)
            

            if (self.zoom_mode==ZoomMode.ZoomIn or self.zoom_mode==ZoomMode.ZoomOut) or (self.panDelta[0] != 0 or self.panDelta[1] != 0) or self.scalerCropUpdate:
                self.updateScalerCrop()

            else:
                self.zoom_mode = None

        self.lastDraw = time.time()


class StreamingHandler(server.BaseHTTPRequestHandler):
    counter = 0

    def do_GET(self):
        if self.path == '/status':
            if(isCSICameraAttached == False):
                self.send_response(404)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                return
            else:
                self.send_response(200)
                self.send_header('Content-Type', 'text/event-stream')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                #self.wfile.write(str.encode(str(output.zoomScale)))
                self.wfile.write(str.encode(str(output.flipped)))
        elif self.path == '/switchSides':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            output.flipped = not output.flipped
            settings = dict()
            settings["flipped"] = output.flipped
            with open("settings.json", 'w') as f:
                json.dump(settings, f, indent=4)
        elif self.path == '/status-stream':
            if(isCSICameraAttached == False):
                self.send_response(404)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                return
            else:
                self.send_response(200)
                self.send_header('Content-Type', 'text/event-stream')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header("Cache-Control", " no-store")
                self.end_headers()
                while True:
                    self.wfile.write(b'event: ping\n')
                    self.wfile.write(str.encode('data: ' + str(output.writtenZoom) + '\n'))
                    self.wfile.write(b'\n\n')
                    self.flush_headers()
                    #time.sleep(0.1)
        elif self.path == '/fullZoomOut':
                self.send_response(200)
                self.send_header('Content-Type', 'text/event-stream')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                output.oldScalerCrop = output.scalerCrop
                output.oldZoomScale = output.zoomScale
                output.zoomScale = 3.15
                output.updateScalerCrop()
                self.wfile.write(str.encode(str(output.oldScalerCrop) + ' ' + str(output.scalerCropMaximum)))
        elif self.path == '/returnZoom':
                self.send_response(200)
                self.send_header('Content-Type', 'text/event-stream')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                output.zoomScale = output.oldZoomScale
                output.updateScalerCrop()
        elif self.path == '/stream':
            if(isCSICameraAttached == False):
                self.send_response(404)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                return
            
            if not output.streaming:
                #picam2.start_recording(Encoder(), FileOutput(output))
                picam2.start_recording(MJPEGEncoder(bitrate=20000000), FileOutput(output))
            output.streaming = True
            self.send_response(200)
            self.send_header('Age', 0)
            self.send_header('Cache-Control', 'no-cache, private')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=FRAME')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                while True:
                    with output.condition:
                        output.condition.wait()
                        frame = output.frame
                    #self.send_header('Content-Type', 'image/jpeg')
                    #self.send_header('Content-Length', len(frame))
                    #self.end_headers()
                    #self.wfile.write(frame)
                    #self.wfile.write(b'\r\n')
                    #self.wfile.write(b'--FRAME\r\n')
                    self.sendFrame(frame)
                    output.writtenZoom = output.zoomScale

     
            except Exception as e:
                logging.warning('Removed streaming client %s: %s', self.client_address, str(e))
                #if output.streaming:
                    #picam2.stop_recording()
                #output.streaming = False
        elif self.path == '/ocr':
            if(isCSICameraAttached == False):
                self.send_response(404)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                return
                
            self.send_response(200)
            self.send_header('Content-Type', 'text/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                with output.condition:
                    output.condition.wait()
                    frame = output.frame
                    adjustedScalerCrop = [output.scalerCrop[1], output.scalerCrop[0], output.scalerCrop[3], output.scalerCrop[2]]
                    capture_config = picam2.create_video_configuration(
                        #main={"size": (min(max_res['size'][0], output.scalerCrop[2]), min(max_res['size'][1], output.scalerCrop[3]))},
                        main={"size": (min(4492, output.scalerCrop[2]), min(2526, output.scalerCrop[3]))},
                        controls={
                            "ScalerCrop": output.scalerCrop
                        }
                    )
                    
                    time.sleep(1)
                    local_path = os.path.dirname(os.path.realpath(__file__))
                    picam2.switch_mode_and_capture_file(capture_config, local_path+'/csi_snapshot.jpg', wait=True)
                    
                    time.sleep(1)
                    result = subprocess.run(["cd " + OCR_PATH + ";./ocr "+local_path+"/csi_snapshot.jpg"], stdout=subprocess.PIPE, shell=True)
                    
                    self.wfile.write(result.stdout)
                    output.picam2.set_controls({"ScalerCrop": output.scalerCrop})

            except Exception as e:
                logging.warning('Removed streaming client %s: %s', self.client_address, str(e))
        elif self.path == '/ocr-main':
            self.send_response(200)
            self.send_header('Content-Type', 'text/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            try:
                with output.condition:
                    urllib.request.urlretrieve("http://localhost/snapshot", "fhd_snapshot.jpg")
                    local_path = os.path.dirname(os.path.realpath(__file__))
                    result = subprocess.run(["cd " + OCR_PATH + ";./ocr "+local_path+"/fhd_snapshot.jpg"], stdout=subprocess.PIPE, shell=True)
                    
                    self.wfile.write(result.stdout)
            except Exception as e:
                logging.warning(
                    'Removed streaming client %s: %s',
                    self.client_address, str(e))

                
            
        else:
            self.send_error(404)
            self.end_headers()


    def sendFrame(self, frame):
        if output.zoomScale > 1 and self.counter % 2 == 0:
            bytes1 = self.createBytes(output.currentSize[0])
            bytes2 = self.createBytes(output.currentSize[1])
            bytes3 = self.createBytes(output.scalerCropMaximum[2])
            bytes4 = self.createBytes(output.scalerCropMaximum[3])

            imageBytesResult = np.append(bytes1, bytes2)
            imageBytesResult = np.append(imageBytesResult, bytes3)
            imageBytesResult = np.append(imageBytesResult, bytes4)

            _, JPEG = cv2.imencode('.jpeg', imageBytesResult)
            frame = JPEG.tobytes()

        self.send_header('Content-Type', 'image/jpeg')
        self.send_header('Content-Length', len(frame))
        self.end_headers()
        self.wfile.write(frame)
        self.wfile.write(b'\r\n')
        self.wfile.write(b'--FRAME\r\n')

        self.counter += 1
    
    def createBytes(self, number):
        modAmount = number % 255
        divideAmount = int(number / 255)

        result = np.empty(divideAmount, dtype=np.uint8)
        result.fill(255)
        if result.size < 32:
            result = np.append(result, modAmount)
        if result.size < 32:
            zerosLeft = np.empty(32 - result.size, dtype=np.uint8)
            zerosLeft.fill(0)
            result = np.append(result, zerosLeft)
            
        return result
            

class StreamingServer(socketserver.ThreadingMixIn, server.HTTPServer):
    allow_reuse_address = True 
    daemon_threads = True

for cameraInfo in Picamera2.global_camera_info():
    if(cameraInfo['Id'].startswith("/base/soc/i2c0mux")):
        isCSICameraAttached = True

try:
    with open("settings.json", 'r') as f:
        settings = json.load(f)
        output.flipped = settings["flipped"]
except Exception as e:
    print("Settings not found")

try:
    picam2 = Picamera2()
    picam2.options["quality"] = 95 #max is 95
    max_res = picam2.sensor_modes[-1]
    sensor_modes = picam2.sensor_modes
    if 'AfMode' not in picam2.camera_controls:
        print("SKIPPED (no AF available)")
        #quit()
    else:
        print("AF available")
    picam2.configure(picam2.create_video_configuration(
        #main={"size": (1280, 720)},
        main={"size": (720, 1280)},
        raw={"format": 'SGBRG10', 'size': (2304, 1296)},
        colour_space=ColorSpace.Sycc(),
        controls={
            "NoiseReductionMode": controls.draft.NoiseReductionModeEnum.Off,
            "FrameDurationLimits": (30000, 30000), 
            'AfMode': controls.AfModeEnum.Continuous
        },
        encode="main"
    ))
    output = StreamingOutput(picam2)
    #picam2.start_recording(JpegEncoder(q=95), FileOutput(output))
    #picam2.autofocus_cycle(None,None)
except Exception as e:
    output = StreamingOutput(None)
    print(e)
import asyncio
import threading
import websockets
async def websocket_handler(websocket, path):
    while True:
        try:
            message = await websocket.recv()
            print(f"Received message: {message}")
        except Exception as e:
            print(f"Error: {e}")
            break
        
        try:
            data = json.loads(message)
            #print(f"data: {data}")
            
            command = data["message"]
            #print(f"command: {command}")
            if command == 'zoomin':
                output.setZoom(ZoomMode.ZoomIn)
            elif command == 'zoomout':
                output.setZoom(ZoomMode.ZoomOut)
            elif command == 'zoomstop':
                output.setZoom(ZoomMode.ZoomStop)
            elif command == 'up':
                output.setPan([0,-1])
            elif command == 'left':
                output.setPan([-1,0])
            elif command == 'right':
                output.setPan([1,0])
            elif command == 'down':
                output.setPan([0,1])
            elif command == 'stopVertical':
                output.setPan([0,0])
            elif command == 'stopHorizontal':
                output.setPan([0,0])
            elif command == 'autofocus':
                picam2.autofocus_cycle(None,None)
            # Add more cases as needed
        except json.JSONDecodeError:
            print("Invalid JSON received")
        await websocket.send(json.dumps({"message": "success", "command": f"{command}"}))
# ... (your existing code)
def start_websocket_server():
    asyncio.set_event_loop(asyncio.new_event_loop())
    server = websockets.serve(websocket_handler, "0.0.0.0", 9002)
    asyncio.get_event_loop().run_until_complete(server)
    asyncio.get_event_loop().run_forever()
try:
    # Start the WebSocket server on a background thread
    websocket_thread = threading.Thread(target=start_websocket_server)
    websocket_thread.start()
    address = ('', 8080)
    server = StreamingServer(address, StreamingHandler)
    server.serve_forever()
finally:
    picam2.stop_recording()