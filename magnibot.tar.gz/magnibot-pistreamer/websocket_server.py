# File: websocket_server.py
import asyncio
import websockets

class WebSocketServer:
    def __init__(self, host, port):
        self.host = host
        self.port = port

    async def echo(self, websocket, path):
        print(f"Client connected from {websocket.remote_address}")

        try:
            async for message in websocket:
                print(f"Received message from {websocket.remote_address}: {message}")
                await websocket.send(message)
                print(f"Sent message to {websocket.remote_address}: {message}")
        except websockets.exceptions.ConnectionClosed:
            print(f"Connection with {websocket.remote_address} closed")

    async def start_server(self):
        server = await websockets.serve(self.echo, self.host, self.port)
        print(f"WebSocket server started on ws://{server.sockets[0].getsockname()[0]}:{server.sockets[0].getsockname()[1]}")
        await server.wait_closed()
        print("Server closed")
        self.start_server()
