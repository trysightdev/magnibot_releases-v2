# File: main_script.py
import asyncio
from websocket_server import WebSocketServer

if __name__ == "__main__":
    server = WebSocketServer("0.0.0.0", 8001)
    asyncio.run(server.start_server())
