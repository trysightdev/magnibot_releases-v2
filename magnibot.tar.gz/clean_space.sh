#!/bin/bash

# Define the clear_space function
clear_space() {
    # Add code to clear space on the root drive
    echo "Clearing space on root drive"
    sudo journalctl --vacuum-size=10M
    sudo truncate -s 0 /var/log/syslog
    sudo truncate -s 0 /var/log/daemon.log
    sudo truncate -s 0 /var/log/kern.log
    
    # sudo rm /var/log/test.log
    
    cp settings.default.json settings.json
    rm -rf /home/pi/.vscode-server/
}

# Check if the root drive has over 6GB of free space
root_free_space=$(df -B 1 / | awk 'NR==2 {print $4}')
if [ "$root_free_space" -lt $((2*1024*1024*1024)) ]; then
    echo "Root drive has less than 2GB of free space"
    clear_space
fi
exit 0