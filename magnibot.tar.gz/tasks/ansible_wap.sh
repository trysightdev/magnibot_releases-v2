#!/bin/bash

# Exit on first error.
set -e

# Echo commands to stdout.
set -x
{
PROJECT_NAME="test_project"
# rm -rf ~/$PROJECT_NAME
mkdir ~/$PROJECT_NAME
cd ~/$PROJECT_NAME

# Install Magnibot
python3 -m venv venv
. venv/bin/activate
pip install ansible
echo "[defaults]
roles_path = $PWD
interpreter_python = /usr/bin/python3
" > ansible.cfg

ansible-playbook setup_wap.yml
}