# Magnibot
## Program Overview

![](<static/images/magnibot.drawio.png>)

### Magnibot Services
These are the services that are **manually created** and modified for magnibot. These files are located in
```/etc/systemd/system/``` folder.

**magnibot.service** - Website application that serves the html,js,and css files

**magnibot_updater.service** - Allows for remote updates to magnibot when connected to the internet

**ustreamer.service** - Creates TCP video stream 

### Third Party Services
These services are **automatically created** when they are installed using ```apt``` and are located in
```/usr/lib/systemd/system/``` folder.

**hostapd.service** - Creates hotspot called ```magnibot_012345```

**dhcpcd.service** - Sets ```192.168.4.1``` as a static IP address

**nginx.service** - Webserver which makes ```magnibot``` accessible at ```192.168.4.1```

**pisugar-server.service** - PiSugar server to get battery percentage

**wpa_supplicant.service** - Connects to Internet using USB Wifi

**janus.service** - Streams H264 video directly to browser using websockets and JS *Only used when set to H264*

## Quick Install (SVN)
Clone repo and run **quick_install.sh**
```
cd ~/
rm -rf magnibot/
rm -rf magnibot_updater/
sudo apt update && sudo apt install git -y
git clone https://{{GITHUB KEY FROM ZOHO}}@github.com/trysightdev/magnibot-v2.git
git clone https://{{GITHUB KEY FROM ZOHO}}@github.com/trysightdev/magnibot_updater.git
cd magnibot
chmod +x quick_install.sh
./quick_install.sh
```
## Run through terminal
Stop magnibot service if running than run flask through the venv
```
sudo systemctl stop magnibot.service
cd ~/magnibot
source venv/bin/activate
python app.py

```

## Dependencies
- [UStreamer](https://github.com/bmagsalan/ustreamer.git)
- [Nginx 1.18](https://docs.nginx.com/nginx/admin-guide/installing-nginx/installing-nginx-open-source/)
- [Flask](https://flask.palletsprojects.com/en/2.1.x/installation/)
- [Flask-SocketIO](https://github.com/miguelgrinberg/Flask-SocketIO)
- [RpiMotorLib](https://github.com/gavinlyonsrepo/RpiMotorLib)
- [ContactJS](https://github.com/biodiv/contactjs)
- [Raspberry-Pi-Automated-WiFi-Access-Point](https://github.com/arm358/Raspberry-Pi-Automated-WiFi-Access-Point)
- [Pisugar Power Off](https://issist.repositoryhosting.com/svn/issist_magnibot/trunk/pisugar-power-manager-rs/)
## Additional Links 
- [Python threading](https://superfastpython.com/thread-long-running-background-task/)
- [I2C Commands](https://www.abelectronics.co.uk/kb/article/1092/i2c-part-3---i-c-tools-in-linux#:~:text=Available%20Commands%20in%20I2C%20Tools&text=i2cdump%20Examine%20and%20read%20I2C,transfer%20to%20a%20connected%20device.)
- [Raspberry WiFi Repeater](https://github.com/ArieLevs/Raspberry-WiFi-Repeater)
- [Wifi extender](https://pimylifeup.com/raspberry-pi-wifi-extender/)
- [USB Wifi Module Driver](https://github.com/morrownr/88x2bu-20210702)
- [Delete IP Tables](https://www.cyberciti.biz/faq/how-to-iptables-delete-postrouting-rule/)
- [TP Link Driver AC600](https://github.com/morrownr/8812au-20210629)
