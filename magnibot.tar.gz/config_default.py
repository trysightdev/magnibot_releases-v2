"""Flask configuration."""

TESTING = True
DEBUG = True
FLASK_ENV = 'development'
SECRET_KEY = 'GDtfDCFYjD'
SEND_FILE_MAX_AGE_DEFAULT = 0
ENABLE_MOTORS = True
DISABLE_HTML_LOGGING = True

