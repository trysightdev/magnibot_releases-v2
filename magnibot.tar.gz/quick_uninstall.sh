#!/bin/bash

{ # Prevent the script from executing until the client downloads the full file.

# Exit on first error.
set -e

# Echo commands to stdout.
set -x


PROJECT_NAME='magnibot'
sudo systemctl stop $PROJECT_NAME.service
sudo systemctl disable $PROJECT_NAME.service
sudo rm -f /etc/systemd/system/$PROJECT_NAME.service

PROJECT_NAME='ustreamer'
sudo systemctl stop $PROJECT_NAME.service
sudo systemctl disable $PROJECT_NAME.service
sudo rm -f /etc/systemd/system/$PROJECT_NAME.service
sudo rm -f /usr/bin/$PROJECT_NAME

PROJECT_NAME='nginx.service'
sudo systemctl stop $PROJECT_NAME.service
sudo systemctl disable $PROJECT_NAME.service
sudo rm -f /etc/sysitemd/system/$PROJECT_NAME.service
sudo apt remove $PROJECT_NAME -y

sudo rm -rf /usr/share/janus
sudo rm -rf /usr/lib/arm-linux-gnueabihf/janus/plugins
sudo rm -rf /etc/janus

sudo apt purge janus janus-dev -y
} # Prevent the script from executing until the client downloads the full file.


