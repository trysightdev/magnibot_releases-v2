#!/bin/bash

{ # Prevent the script from executing until the client downloads the full file.

# Exit on first error.
set -e

# Echo commands to stdout.
set -x

while getopts m:r:f: flag
do
    case "${flag}" in
        m) VIDEO_FORMAT=${OPTARG};;
        r) RESOLUTION=${OPTARG};;
        f) FPS=${OPTARG};;
    esac
done


USTREAMER_FILE='ustreamer.service'
USTREAMER_MJPEG_OPTS="--host 127.0.0.1 --port 8001 --encoder hw --format jpeg --resolution $RESOLUTION --desired-fps $FPS --quality 100 --persistent"
USTREAMER_H264_OPTS="--host 127.0.0.1 --port 8001 --encoder hw --format jpeg --resolution $RESOLUTION --desired-fps $FPS --quality 100 --persistent --h264-sink tinypilot::ustreamer::h264 --h264-sink-mode 777 --h264-sink-rm --h264-bitrate 20000"

if [ $VIDEO_FORMAT = 'H264' ]
then
USTREAMER_CMD="ustreamer ${USTREAMER_H264_OPTS}"
else
USTREAMER_CMD="ustreamer ${USTREAMER_MJPEG_OPTS}"
fi
cat << EOF > $USTREAMER_FILE
[Unit]
Description=uStreamer - Lightweight, optimized video encoder

After=syslog.target network.target
[Service]
User=$(whoami)
ExecStartPre=/bin/sleep 15
#ExecStartPre=/bin/sleep 25
ExecStart=$USTREAMER_CMD
                                                                                                                                                                                                                       
Restart=always
[Install]
WantedBy=multi-user.target
EOF
sudo cp -f $USTREAMER_FILE  /etc/systemd/system/
sudo systemctl daemon-reload
# sudo systemctl restart $USTREAMER_FILE


} # Prevent the script from executing until the client downloads the full file.


