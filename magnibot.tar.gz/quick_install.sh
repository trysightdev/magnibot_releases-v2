#!/bin/bash

{ # Prevent the script from executing until the client downloads the full file.

# Exit on first error.
set -e

# Echo commands to stdout.
set -x

sudo apt update
sudo apt install python3-pip python3-dev build-essential libssl-dev libffi-dev python3-setuptools -y
sudo apt install python3-venv -y


PROJECT_NAME="magnibot-v2"
cd ~/$PROJECT_NAME
# Raspberry Pi 32: armv7l
# Desktop:  x86_64
cd lib/src
g++ -fPIC -c -o zoom.o zoomctrltest.cpp -lzoomctrl

MACHINE_TYPE=`getconf LONG_BIT`
if [ ${MACHINE_TYPE} == '32' ]; then
	sudo cp raspberry_x32/libzoomctrl.so /usr/lib/
else
	sudo cp pc_x64/libzoomctrl.so /usr/lib/
fi
# Create shared library (e.g. libzoom.so)
g++ -shared -o ../libzoom.so zoom.o -lzoomctrl
# Create binary 
g++ -o ../zoom.bin zoomctrltest.cpp -lzoomctrl

# Install PiSugar 2 Pro binaries and dependencies
cd ~/$PROJECT_NAME/lib
tar -xvzf pisugar-poweroff.tar.gz
sudo apt install i2c-tools -y
sudo raspi-config nonint do_i2c 0

cd ~/$PROJECT_NAME

# Install Magnibot
python3 -m venv venv
. venv/bin/activate

pip install pip==21.3.1
pip install -r requirements.txt

# Desktop:  x86_64
DEFAULT_CONFIG="config_default.py"
MAGNIBOT_CONFIG="config.py"

cp -rf $DEFAULT_CONFIG $MAGNIBOT_CONFIG

if [ ${MACHINE_TYPE} == 'x86_64' ]; then
	pip uninstall flask jinja2 -y
	pip install flask jinja2 
	sed -i 's/ENABLE_MOTORS.*/ENABLE_MOTORS = False/g' $MAGNIBOT_CONFIG
else
	sed -i 's/ENABLE_MOTORS.*/ENABLE_MOTORS = True/g' $MAGNIBOT_CONFIG
fi

sudo chmod 755 /home/$(whoami)

SERVICE_FILE="$PROJECT_NAME.service"
cat << EOF > $SERVICE_FILE
[Unit]
Description=$PROJECT_NAME service
After=network.target

[Service]
User=$(whoami)
Group=www-data
WorkingDirectory=/home/$(whoami)/$PROJECT_NAME
ExecStartPre=/bin/sleep 10
ExecStart=/home/$(whoami)/$PROJECT_NAME/venv/bin/python app.py

[Install]
WantedBy=multi-user.target
EOF
sudo cp -f $SERVICE_FILE  /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start $SERVICE_FILE
sudo systemctl enable $SERVICE_FILE

## Install Ustreamer
sudo apt install git -y
sudo apt install build-essential libevent-dev libjpeg9-dev libbsd-dev -y
cd ~/
rm -rf ustreamer/
git clone https://github.com/bmagsalan/ustreamer.git
cd ustreamer
make
sudo cp -rf ~/ustreamer/src/ustreamer.bin /usr/bin/
sudo mv /usr/bin/ustreamer.bin /usr/bin/ustreamer
sudo chown root:root /usr/bin/ustreamer
rm -rf ~/ustreamer/

cd ~/$PROJECT_NAME

USTREAMER_FILE='ustreamer.service'
cat << EOF > $USTREAMER_FILE
[Unit]
Description=uStreamer - Lightweight, optimized video encoder

After=syslog.target network.target
[Service]
User=$(whoami)
ExecStartPre=/bin/sleep 15
ExecStart=ustreamer --host 127.0.0.1 --port 8001 --encoder hw --format jpeg --resolution 1280x720 --desired-fps 30

Restart=always
[Install]
WantedBy=multi-user.target
EOF
sudo cp -f $USTREAMER_FILE  /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start $USTREAMER_FILE
sudo systemctl enable $USTREAMER_FILE

sudo apt install nginx -y

NGINX_FILE='default'
cat << EOF > $NGINX_FILE
server {

	listen 80 default_server;
	listen [::]:80 default_server;
	
	root /var/www/your_domain/html;
	index index.html
	server_name _;
	
	location / {
		include proxy_params;
		proxy_pass http://127.0.0.1:5000;
	}
	location /stream {
		postpone_output 0;
		proxy_buffering off;
		proxy_ignore_headers X-Accel-Buffering;
		proxy_pass http://127.0.0.1:8001;
	}
	location /socket.io {
		proxy_pass http://127.0.0.1:5000/socket.io;
		proxy_http_version 1.1;
		proxy_buffering off;
		
		proxy_set_header Upgrade \$http_upgrade;
		proxy_set_header Connection \"Upgrade\";
		proxy_set_header Host \$http_host;
		
		proxy_set_header X-Forwarded-Host \$http_host;
		proxy_set_header X-Forwarded-Proto \$scheme;
	}
}
EOF
sudo cp -f $NGINX_FILE  /etc/nginx/sites-available/default
sudo systemctl daemon-reload
sudo systemctl restart nginx.service 


# Install Magnibot
PROJECT_NAME="magnibot_updater"
cd ~/$PROJECT_NAME
python3 -m venv venv
. venv/bin/activate

pip install pip==21.3.1
pip install -r requirements.txt

SERVICE_FILE="$PROJECT_NAME.service"
cat << EOF > $SERVICE_FILE
[Unit]
Description=$PROJECT_NAME service
After=network.target

[Service]
User=$(whoami)
Group=www-data
WorkingDirectory=/home/$(whoami)/$PROJECT_NAME
ExecStartPre=/bin/sleep 10
ExecStart=/home/$(whoami)/$PROJECT_NAME/venv/bin/python app.py

[Install]
WantedBy=multi-user.target
EOF

sudo cp -f $SERVICE_FILE  /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start $SERVICE_FILE
sudo systemctl enable $SERVICE_FILE
} # Prevent the script from executing until the client downloads the full file.


