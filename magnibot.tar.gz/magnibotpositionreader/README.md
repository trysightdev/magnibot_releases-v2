# MagnibotPositionReader
## Install required libraries
```
git clone https://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@github.com/trysightdev/magnibotpositionreader.git
sudo apt install arduino
sudo ln -s Caterina-Leonardo.hex /usr/share/arduino/hardware/arduino/avr/bootloaders/caterina/Caterina-Leonardo.hex
sudo cp leonardoUploader.bin /usr/bin
```

## Compile hex and install
```
arduino --board arduino:avr:leonardo --pref build.path=build --verify MagnibotPositionReader.ino
sudo leonardoUploader.bin /dev/ttyACM0 build/MagnibotPositionReader.ino.hex
```
