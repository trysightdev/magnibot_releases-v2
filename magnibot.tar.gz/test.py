import RPi.GPIO as GPIO
import RpiMotorLib as RpiMotorLib
import threading
STEP_TYPE = "full"
motor = RpiMotorLib.BYJMotor("HorizontalMotor", "28BYJ")
motor1 = RpiMotorLib.BYJMotor("VerticalMotor", "28BYJ")
vGpioPins = [8,10,12,16]
hGpioPins = [29,31,33,35]

MAX_SPEED_VERT = 0.005
MAX_SPEED_HORIZONTAL = 0.003

# Define your two functions
def function1():
    print(f"function1")
    while True:
        print(f"function1")
        motor.motor_test(vGpioPins,MAX_SPEED_VERT,True,False,STEP_TYPE, .00, 512)
        motor.motor_test(vGpioPins,MAX_SPEED_VERT,False,False,STEP_TYPE, .00, 512)

def function2():
    print(f"function2")
    while True:
        motor1.motor_test(hGpioPins,MAX_SPEED_HORIZONTAL,True,False,STEP_TYPE, .00, 512)
        motor1.motor_test(hGpioPins,MAX_SPEED_HORIZONTAL,False,False,STEP_TYPE, .00, 512)


if __name__ == "__main__":
    # Create two thread objects
    thread1 = threading.Thread(target=function1)
    thread2 = threading.Thread(target=function2)
    # Start the threads
    thread1.start()
    thread2.start()


    # Wait for both threads to finish (optional)
    thread1.join()
    thread2.join()

