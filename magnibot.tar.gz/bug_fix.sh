#!/bin/bash

{ # Prevent the script from executing until the client downloads the full file.

# Exit on first error.
set -e

# Echo commands to stdout.
set -x

PROJECT_NAME="magnibot"

cd ~/$PROJECT_NAME

SERVICE_FILE="$PROJECT_NAME.service"
cat << EOF > $SERVICE_FILE
[Unit]
Description=$PROJECT_NAME service

#After=syslog.target network.target
After=syslog.target network.target wpa_supplicant.service

[Service]
User=$(whoami)
Group=www-data
WorkingDirectory=/home/$(whoami)/$PROJECT_NAME
# Added 10 sleep to wait for USB devices to finish loading
ExecStartPre=/bin/sleep 10
ExecStart=/home/$(whoami)/$PROJECT_NAME/venv/bin/python app.py

[Install]
WantedBy=multi-user.target
EOF
sudo cp -f $SERVICE_FILE  /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start $SERVICE_FILE
sudo systemctl enable $SERVICE_FILE

## Install Ustreamer
cd ~/$PROJECT_NAME

USTREAMER_FILE='ustreamer.service'
cat << EOF > $USTREAMER_FILE
[Unit]
Description=uStreamer - Lightweight, optimized video encoder

# Wait for server to start before starting ustreamer
After=$PROJECT_NAME.service

[Service]
User=$(whoami)

# Added 3 second delay after webservice starts because if you start it too fast than you get dark video
ExecStartPre=/bin/sleep 3
ExecStart=ustreamer --host 127.0.0.1 --port 8001 --encoder hw --format jpeg --resolution 1280x720 --desired-fps 30

Restart=always
[Install]
WantedBy=multi-user.target
EOF
sudo cp -f $USTREAMER_FILE  /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl start $USTREAMER_FILE
sudo systemctl enable $USTREAMER_FILE


NGINX_FILE='default'
cat << EOF > $NGINX_FILE
server {

	listen 80 default_server;
	listen [::]:80 default_server;
	
	root /var/www/your_domain/html;
	index index.html
	server_name _;
	
	location / {
		include proxy_params;
		proxy_pass http://127.0.0.1:5000;
	}
	location /stream {
		postpone_output 0;
		proxy_buffering off;
		proxy_ignore_headers X-Accel-Buffering;
		proxy_pass http://127.0.0.1:8001;
	}
	location /snapshot {
		postpone_output 0;
		proxy_buffering off;
		proxy_ignore_headers X-Accel-Buffering;
		proxy_pass http://127.0.0.1:8001;
	}
	location /socket.io {
		proxy_pass http://127.0.0.1:5000/socket.io;
		proxy_http_version 1.1;
		proxy_buffering off;
		
		proxy_set_header Upgrade \$http_upgrade;
		proxy_set_header Connection \"Upgrade\";
		proxy_set_header Host \$http_host;
		
		proxy_set_header X-Forwarded-Host \$http_host;
		proxy_set_header X-Forwarded-Proto \$scheme;
	}
}
EOF
sudo cp -f $NGINX_FILE  /etc/nginx/sites-available/default
sudo systemctl daemon-reload
sudo systemctl restart nginx.service 


} # Prevent the script from executing until the client downloads the full file.


