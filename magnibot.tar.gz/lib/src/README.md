# Build instructions
1. Copy the **libzoomctrl.so** for the machine architecture used to the **/usr/lib/** folder.
2. Build the **zoom.o** file.
```
g++ -c -o zoom.o zoomctrltest.cpp -lzoomctrl 
```
3. Build the shared library (.so) file with the following command:
```
g++ -shared -o libzoom.so zoom.o -lzoomctrl
```
4. Double check and see if the **zoomIn** and **zoomOut** functions are exported correctly:
```
nm libzoom.so
```
5. Move the library up a folder where the **app.py** will reference it directly:
```
from ctypes import *
so_file = "./lib/libzoom.so"
my_functions = CDLL(so_file)

print( type(my_functions) )
my_functions.zoomIn()
```

## Terminal Commands
```
q -> Quit
i -> Zoom In
o -> Zoom Out
s -> Zoom Stop
t -> 30cm focus
f -> Infinite focus
g -> Get Zoom
z -> 60 hz 
x -> 50 hz
```


