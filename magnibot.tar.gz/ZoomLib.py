from ctypes import *
import sys
import os
from subprocess import Popen, PIPE
import time

# Run binary https://stackoverflow.com/questions/9322796/keep-a-subprocess-alive-and-keep-giving-it-commands-python
class ZoomLib(object):
    def __init__(self, access_type="library"):
        self.access_type = access_type
        self.lib_path = "./lib/"
        self.isZooming = False
        if self.access_type == "library":
            self.my_functions = CDLL(self.lib_path + "libzoom.so")
            result = self.my_functions.zoomOpen(0)
            print("init_library: " + str(result))
        elif self.access_type == "binary":
            self.process = Popen([self.lib_path + 'zoom.bin'], stdin=PIPE, stdout=PIPE)
            print("init binary")


    def zoomStop(self):
        result = 0
        if self.access_type == "library":
            result = self.my_functions.zoomStop()
        elif self.access_type == "binary":
            self.process.stdin.write(b's\n')
            self.process.stdin.flush()
            output = self.process.stdout.readline().decode("utf-8").strip().split() 
            result = int(output[1])
        self.isZooming = False
        return result
    def zoomGet(self):
        result = 0
        self.process.stdin.write(b'g\n')
        self.process.stdin.flush()
        output = self.process.stdout.readline().decode("utf-8").strip().split() 
        result = int(output[1])
        self.isZooming = False
        return result

    def zoomIn(self):
        if self.isZooming:
            print("isZooming")
 #           return

        self.isZooming = True
        if self.access_type == "library":
            result = self.my_functions.zoomIn()
            print("zoomIn: " + str(result));
        elif self.access_type == "binary":
            self.process.stdin.write(b'i\n')
            self.process.stdin.flush()
            # print("zoomIn")

    def zoomOut(self):
        if self.isZooming:
            print("isZooming")
  #          return

        self.isZooming = True

        if self.access_type == "library":
            result = self.my_functions.zoomOut()
            print("zoomOut: " + str(result));
        elif self.access_type == "binary":
            self.process.stdin.write(b'o\n')
            self.process.stdin.flush()
            print("zoomOut")

    def zoomFocusThirty(self):
        if self.isZooming:
            print("isZooming")
        self.isZooming = True
        self.process.stdin.write(b't\n')
        self.process.stdin.flush()
        output = self.process.stdout.readline().decode("utf-8").strip().split() 
        result = output[0]
        while True:
            print(result)
            if "finished" in result:
                self.process.stdout.flush()
                break
        self.isZooming = False
        print("zoomFocusThirty")

    def zoomFocusInfinity(self):
        if self.isZooming:
            print("isZooming")
        self.isZooming = True
        self.process.stdin.write(b'f\n')
        self.process.stdin.flush()
        output = self.process.stdout.readline().decode("utf-8").strip().split() 
        result = output[0]
        while True:
            print(result)
            if "finished" in result:
                self.process.stdout.flush()
                break
        self.isZooming = False
        print("zoomFocusInfinity")
    
    def setRefreshRate(self, pMode=0):
        if self.isZooming:
            print("isZooming")
        self.isZooming = True
        if pMode==1:
            self.process.stdin.write(b'z\n')
        else:
            self.process.stdin.write(b'x\n')
        self.process.stdin.flush()
        self.process.stdout.flush()
        self.isZooming = False
        print("setRefreshRate: ", pMode)


    
