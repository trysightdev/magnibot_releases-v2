const videoElement = document.getElementById("video_preview")
const vertexShader = `
attribute vec2 a_position;
attribute vec2 a_texCoord;
uniform vec2 u_resolution;
varying vec2 vTextureCoord;
void main() {
   // convert the rectangle from pixels to 0.0 to 1.0
   vec2 zeroToOne = a_position / u_resolution;
   // convert from 0->1 to 0->2
   vec2 zeroToTwo = zeroToOne * 2.0;
   // convert from 0->2 to -1->+1 (clipspace)
   vec2 clipSpace = zeroToTwo - 1.0;
   gl_Position = vec4(clipSpace * vec2(1, -1), 0, 1);
   //gl_Position = a_position;
   // pass the texCoord to the fragment shader
   // The GPU will interpolate this value between points.
   vTextureCoord = a_texCoord;
}`;
let splitscreen_currentShaderIndex = 0;
let splitscreen_fragmentShader = FRAGMENT_SHADERS[0];

let currentShaderIndex = 0;
let fragmentShader = FRAGMENT_SHADERS[0];
function cycleShaders(splitscreen) {
    const gl = splitscreen ? glSplitscreen : glMain;
    let shaderIndex = splitscreen ? splitscreen_currentShaderIndex : currentShaderIndex;
    const buffers = splitscreen ? glBuffersSplitscreen : glBuffers;
    gl.deleteBuffer(buffers.positionBuffer);
    gl.deleteBuffer(buffers.texcoordBuffer);
    gl.deleteTexture(buffers.texture);
    shaderIndex = (shaderIndex + 1) % FRAGMENT_SHADERS.length;
    let newFragmentShader = FRAGMENT_SHADERS[shaderIndex];
    // If current color was deactivated in settings, load the next active color
    var loopCounter = 0;
    while (newFragmentShader.enabled == false) {
        // Limit the loop around to one cycle than breakout
        if (loopCounter >= FRAGMENT_SHADERS.length)
            break;
            shaderIndex = (shaderIndex + 1) % FRAGMENT_SHADERS.length;
        newFragmentShader = FRAGMENT_SHADERS[shaderIndex];
        loopCounter++;
        console.log("Max loops: " + loopCounter);
    }

    if (splitscreen) {
        socket.emit('set_shaderIndexPi', { splitscreenShaderIndex: shaderIndex });
        splitscreen_currentShaderIndex = shaderIndex;
        splitscreen_fragmentShader = newFragmentShader;
        setup(splitscreenManager.image, splitscreenManager.canvas, true);
    } else {
        socket.emit('set_shaderIndex', { shaderIndex: shaderIndex });
        currentShaderIndex = shaderIndex;
        fragmentShader = newFragmentShader;
        init();
    }

    saveUISettings();
}
function updateOpenGLCanvas(splitscreen) {
    const gl = splitscreen ? glSplitscreen : glMain;
    const buffers = splitscreen ? glBuffersSplitscreen : glBuffers;
    gl.deleteBuffer(buffers.positionBuffer);
    gl.deleteBuffer(buffers.texcoordBuffer);
    gl.deleteTexture(buffers.texture);
    if (splitscreen) {
        splitscreen_fragmentShader = FRAGMENT_SHADERS[splitscreen_currentShaderIndex];
    } else {
        fragmentShader = FRAGMENT_SHADERS[currentShaderIndex];
    }
    
    if (splitscreen) {
        setup(splitscreenManager.image, splitscreenManager.canvas, true);
    } else {
        init();
    }
}
let image = new Image();
image.decoding = "sync";
image.fetchPriority = "high";
let imageCapture;
let loaded = false;
socket.on('first_connect', function (msg) {
    console.log(msg);
    let magnibotSettings = msg.magnibotSettings;
    //brightnessValue = parseFloat(msg.calibrated_brightness);
    //contrastValue = parseFloat(msg.calibrated_contrast);
    contrast_A = magnibotSettings.calibrated_brightness;
    contrast_C = magnibotSettings.calibrated_brightnessC;
    contrast = magnibotSettings.calibrated_contrast;
    let shadersEnabled = magnibotSettings.fragmentShaders;
    splitscreen_currentShaderIndex = parseInt(magnibotSettings.splitscreenShaderIndex ?? 0);
    currentShaderIndex = parseInt(magnibotSettings.shaderIndex[1] ?? 0);
    var lastEnabledShader = 0;
    for (var i = 0; i < shadersEnabled.length; i++) {
        var enabledColor = parseInt(shadersEnabled[i]) == 0 ? false : true;
        FRAGMENT_SHADERS[i].enabled = enabledColor;
        if (enabledColor)
            lastEnabledShader = i;
    }
    if (FRAGMENT_SHADERS[currentShaderIndex].enabled == 0)
        currentShaderIndex = lastEnabledShader;

    splitscreen_fragmentShader = FRAGMENT_SHADERS[splitscreen_currentShaderIndex];
    fragmentShader = FRAGMENT_SHADERS[currentShaderIndex];
    //init();
});

function usePiCamera() {
    document.cookie = "camera=pi"; //adds to a list/overwrites key even tho its only setting a single value
    image.crossOrigin = "anonymous";
    image.src = `http://${document.location.host}:8080/stream`;
    image.onload = function () {
        setup(image, document.querySelector("#renderTarget"));
        requestFrame(image);
        loaded = true;
    };
}

function useFHDCamera() {
    document.cookie = "camera=fhd"; //adds to a list/overwrites key even tho its only setting a single value
    image.src = "/stream";
    image.onload = function () {
        setup(image, document.querySelector("#renderTarget"));
        requestFrame(image);
        loaded = true;
    };
}

function init() {
    const renderTarget = document.querySelector("#renderTarget")
    if (videoElement == undefined) {
        if (loaded) {
            setup(image, renderTarget);
        } else {
            if (document.cookie.includes("camera=pi")) {
                usePiCamera();
            } else {
                useFHDCamera();
            }
        }
    } else if (videoElement.nodeName == "VIDEO") {
        if (loaded) {
            setup(videoElement, renderTarget);
        } else {
            videoElement.addEventListener("loadedmetadata", ({ target }) => {
                setup(videoElement, renderTarget);
                requestFrame(videoElement);
                loaded = true;
            });
        }
    }
}

function requestFrame(image, splitscreen) {
    // Stop rendering if paused
    if(splitscreen && !splitscreenVideoRecorder.paused) {
        render(image, splitscreen);
    }else if(!splitscreen && !videoRecorder.paused) {
        render(image, splitscreen);
    }

    window.requestAnimationFrame(() => requestFrame(image, splitscreen));
}
/*
let fragmentShader = `precision mediump float;
// our texture
uniform sampler2D u_image;
// the texCoords passed in from the vertex shader.
varying vec2 vTextureCoord;
void main() {
    vec4 texCol = texture2D(u_image, vTextureCoord);
   gl_FragColor = vec4(1.0 - texCol.r, 1.0 - texCol.g, 1.0 - texCol.b, 1.0);
   //gl_FragColor = texture2D(u_image, vTextureCoord).rgba;
}`;
*/
let glMain;
let glSplitscreen;
function clamp(val, min, max) {
    return Math.min(Math.max(val, min), max);
}

let contrast_A = defaultContrast_A;
let contrast_B = defaultContrast_B;
let contrast_C = defaultContrast_C;
let contrast = defaultContrast;
let contrast_ALocation;
let contrast_BLocation;
let contrast_CLocation;
let contrastLocation;
function resetContrast() {
    contrast = defaultContrast;
    socket.emit('set_contrast', { contrast_value: contrast });
    updateShaderValues();
}
function increaseContrast() {
    contrast = clamp(contrast + 0.075, contrastMin, contrastMax);
    socket.emit('set_contrast', { contrast_value: contrast });
    updateShaderValues();
}
function decreaseContrast() {
    contrast = clamp(contrast - 0.075, contrastMin, contrastMax);
    socket.emit('set_contrast', { contrast_value: contrast });
    updateShaderValues();
}
function resetBrightness() {
    contrast_A = defaultContrast_A;
    contrast_C = defaultContrast_C;
    socket.emit('set_brightness', { brightness_value: contrast_A });
    socket.emit('set_brightnessC', { brightness_value: contrast_C });
    updateShaderValues();
}
function increaseBrightness() {
    if (FRAGMENT_SHADERS[currentShaderIndex].usesCAsBrightness) {
        contrast_C = clamp(contrast_C - 0.015, brightnessMin, brightnessMax);
        socket.emit('set_brightnessC', { brightness_value: contrast_C });
    } else {
        contrast_A = clamp(contrast_A + 0.015, contrast_B + 0.01, contrastMax);
        socket.emit('set_brightness', { brightness_value: contrast_A });
    }
    updateShaderValues();
}
function decreaseBrightness() {
    if (FRAGMENT_SHADERS[currentShaderIndex].usesCAsBrightness) {
        contrast_C = clamp(contrast_C + 0.015, brightnessMin, brightnessMax);
        socket.emit('set_brightnessC', { brightness_value: contrast_C });
    } else {
        contrast_A = clamp(contrast_A - 0.015, contrast_B + 0.01, contrastMax);
        socket.emit('set_brightness', { brightness_value: contrast_A });
    }
    updateShaderValues();
}
function updateShaderValues(splitscreen) {
    const gl = splitscreen ? glSplitscreen : glMain;
    if (contrast_ALocation != undefined) {
        //a cannot go below b otherwise it inverts
        gl.uniform1f(contrast_ALocation, contrast_A);
    }
    if (contrast_BLocation != undefined) {
        gl.uniform1f(contrast_BLocation, contrast_B);
    }
    if (contrast_CLocation != undefined) {
        gl.uniform1f(contrast_CLocation, contrast_C);
    }
    if (contrast != undefined) {
        gl.uniform1f(contrastLocation, contrast);
    }
    console.log(contrast_A, contrast_B, contrast_C, contrast);
}
function render(image, splitscreen) {
    const gl = splitscreen ? glSplitscreen : glMain;
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
    // Draw the rectangle.
    var primitiveType = gl.TRIANGLES;
    var offset = 0;
    var count = 6;
    //gl.clearColor(0, 0, 0, 0);
    // gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(primitiveType, offset, count);
}
function resizeCanvasToDisplaySize(canvas) {
    // Lookup the size the browser is displaying the canvas in CSS pixels.
    const displayWidth = canvas.clientWidth;
    const displayHeight = canvas.clientHeight;
    console.log(displayWidth, displayHeight)
    // Check if the canvas is not the same size.
    const needResize = canvas.width !== displayWidth ||
        canvas.height !== displayHeight;
    if (needResize) {
        // Make the canvas the same size
        canvas.width = displayWidth;
        canvas.height = displayHeight;
    }
    return needResize;
}
let glBuffers = {
    positionBuffer: undefined,
    textcoordBuffer: undefined,
    texture: undefined
};
let glBuffersSplitscreen = {
    positionBuffer: undefined,
    textcoordBuffer: undefined,
    texture: undefined
};
let positionBuffer, texcoordBuffer, texture;
function setup(image, canvas, splitscreen) {
    // Get A WebGL context
    /** @type {HTMLCanvasElement} */
    if (splitscreen) {
        glSplitscreen = canvas.getContext("webgl");
    } else {
        glMain = canvas.getContext("webgl");
    }
    const gl = splitscreen ? glSplitscreen : glMain;
    const buffers = splitscreen ? glBuffersSplitscreen : glBuffers;
    if (!gl) {
        return;
    }

    let program = webglUtils.createProgramFromSources(gl, [vertexShader, splitscreen ? splitscreen_fragmentShader.shader : fragmentShader.shader]);
    // look up where the vertex data needs to go.
    let positionLocation = gl.getAttribLocation(program, "a_position");
    let texcoordLocation = gl.getAttribLocation(program, "a_texCoord");
    // Create a buffer to put three 2d clip space points in
    buffers.positionBuffer = gl.createBuffer();
    webglUtils.resizeCanvasToDisplaySize(canvas);
    // Bind it to ARRAY_BUFFER (think of it as ARRAY_BUFFER = positionBuffer)
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.positionBuffer);
    // Set a rectangle the same size as the image.
    setRectangle(gl, 0, 0, gl.canvas.width, gl.canvas.height);
    // provide texture coordinates for the rectangle.
    buffers.texcoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.texcoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
        0.0, 0.0,
        1.0, 0.0,
        0.0, 1.0,
        0.0, 1.0,
        1.0, 0.0,
        1.0, 1.0,
    ]), gl.STATIC_DRAW);
    // Create a texture.
    buffers.texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, buffers.texture);
    // Set the parameters so we can render any size image.
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    // Upload the image into the texture.
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
    // lookup uniforms
    let resolutionLocation = gl.getUniformLocation(program, "u_resolution");
    contrast_ALocation = gl.getUniformLocation(program, "u_ContrastA");
    contrast_BLocation = gl.getUniformLocation(program, "u_ContrastB");
    contrast_CLocation = gl.getUniformLocation(program, "u_ContrastC");
    contrastLocation = gl.getUniformLocation(program, "contrast");
    // Tell WebGL how to convert from clip space to pixels
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
    // Clear the canvas
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    // Tell it to use our program (pair of shaders)
    gl.useProgram(program);
    // Turn on the position attribute
    gl.enableVertexAttribArray(positionLocation);
    // Bind the position buffer.
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.positionBuffer);
    // Tell the position attribute how to get data out of positionBuffer (ARRAY_BUFFER)
    let size = 2;          // 2 components per iteration
    let type = gl.FLOAT;   // the data is 32bit floats
    let normalize = false; // don't normalize the data
    let stride = 0;        // 0 = move forward size * sizeof(type) each iteration to get the next position
    let offset = 0;        // start at the beginning of the buffer
    gl.vertexAttribPointer(
        positionLocation, size, type, normalize, stride, offset);
    // Turn on the texcoord attribute
    gl.enableVertexAttribArray(texcoordLocation);
    // bind the texcoord buffer.
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.texcoordBuffer);
    // Tell the texcoord attribute how to get data out of texcoordBuffer (ARRAY_BUFFER)
    size = 2;          // 2 components per iteration
    type = gl.FLOAT;   // the data is 32bit floats
    normalize = false; // don't normalize the data
    stride = 0;        // 0 = move forward size * sizeof(type) each iteration to get the next position
    offset = 0;        // start at the beginning of the buffer
    gl.vertexAttribPointer(
        texcoordLocation, size, type, normalize, stride, offset);
    // set the resolution
    gl.uniform2f(resolutionLocation, gl.canvas.width, gl.canvas.height);
    updateShaderValues(splitscreen);
    // Draw the rectangle.
    let primitiveType = gl.TRIANGLES;
    offset = 0;
    let count = 6;
    gl.drawArrays(primitiveType, offset, count);
}
function setRectangle(gl, x, y, width, height) {
    var x1 = x;
    var x2 = x + width;
    var y1 = y;
    var y2 = y + height;
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
        x1, y1,
        x2, y1,
        x1, y2,
        x1, y2,
        x2, y1,
        x2, y2,
    ]), gl.STATIC_DRAW);
}