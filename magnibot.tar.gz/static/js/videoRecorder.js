class VideoRecorder {
    recordedChunks = [];
    recording = false;
    paused = false;
    startTime = Date.now();
    toggleInterval;
    constructor(canvas, videoButton, freezeButton, overlayElement) {
        this.canvas = canvas;
        this.videoButton = videoButton;
        this.freezeButton = freezeButton;
        this.overlayElement = overlayElement;

        let stream = canvas.captureStream();
        this.createMediaStream(stream);

        if (navigator.mediaDevices != undefined) {
            navigator.mediaDevices.getUserMedia({ audio: true })
                .then((audioStream) => {
                    stream.addTrack(audioStream);
                    this.createMediaStream(stream);
                })
        }

        this.videoButton.addEventListener("click", () => {
            this.toggleRecording();
        });
        
        this.freezeButton.addEventListener("click", () => {
            this.toggleFreeze();
        });
    }

    createMediaStream(stream) {
        this.mediaRecorder = new MediaRecorder(stream);
        this.mediaRecorder.ondataavailable = (e) => this.handleDataAvailable(e);
    }

    toggleRecording() {
        if( this.paused )
            return;

        if (!this.recording) {
            this.startRecording();
        } else {
            this.stopRecording();
        }
    }

    startRecording() {
        this.startTime = Date.now();
        this.recordedChunks = [];
        this.recording = true;
        this.mediaRecorder.start();
        this.videoButton.style.backgroundColor = "#ff000088";
        this.videoButton.classList.remove('record_video');
        this.videoButton.classList.add('stop_recording');
        

        // Create a new div element
        var div = document.createElement("div");

        // Add any desired content or styles to the div
        div.style.backgroundColor = "transparent";
        div.style.width = "15vh";
        div.style.height = "15vh";
        div.style.position = "fixed";
        div.style.right = "0";
        
        const canvasRect = this.canvas.getBoundingClientRect();
        const canvasMiddle = canvasRect.top + (canvasRect.height/2);
        div.style.setProperty("top", "calc("+canvasMiddle+"px - 7.5vh)");

        var recordingImage = document.createElement("img");
        recordingImage.id = "recording-blink";
        recordingImage.src = "/images/recording.png";
        recordingImage.style.width = "100%";
        recordingImage.style.height = "100%";

        div.appendChild(recordingImage);

        this.overlayElement.innerHTML = "";

        // Add the created div to the overlay6 element
        this.overlayElement.appendChild(div);
        this.overlayElement.style.display = "inline";
        this.overlayElement.style.pointerEvents = "none";
        this.toggleInterval = setInterval(function(){
            var recordingBlink = div;
            if( recordingBlink  )
            {
                recordingBlink.style.display = recordingBlink.style.display === "none" ? "block" : "none";
            }
        }, 500);
        
        
    }

    stopRecording() {
        this.recording = false;
        this.mediaRecorder.stop();
        this.videoButton.style.backgroundColor = "";
        this.videoButton.classList.remove('stop_recording');
        this.videoButton.classList.add('record_video');

        clearInterval(this.toggleInterval, 500);
        this.overlayElement.innerHTML = "";
        this.overlayElement.style.pointerEvents = "auto";
        this.overlayElement.style.display = "none";
    }

    freezeVideo() {
        this.paused = true;
        // freezeButton.style.backgroundColor = "#00aaff";
        this.freezeButton.style.backgroundColor = "#ff000088";
        
        this.freezeButton.classList.remove('freeze');
        this.freezeButton.classList.add('stop_recording');

        // Create a new div element
        var div = document.createElement("div");

        // Add any desired content or styles to the div
        div.style.backgroundColor = "transparent";
        div.style.width = "15vh";
        div.style.height = "15vh";
        div.style.position = "fixed";
        div.style.right = "0";

        const canvasRect = this.canvas.getBoundingClientRect();
        const canvasMiddle = canvasRect.top + (canvasRect.height/2);
        div.style.setProperty("top", "calc("+canvasMiddle+"px - 7.5vh)");

        var recordingImage = document.createElement("img");
        recordingImage.id = "recording-blink";
        recordingImage.src = "/images/freeze_blink.png";
        recordingImage.style.width = "100%";
        recordingImage.style.height = "100%";

        div.appendChild(recordingImage);

        this.overlayElement.innerHTML = "";

        this.overlayElement.appendChild(div);
        this.overlayElement.style.display = "inline";
        this.overlayElement.style.pointerEvents = "none";
        this.toggleInterval = setInterval(function(){
            var recordingBlink = div;
            if( recordingBlink  )
            {
                recordingBlink.style.display = recordingBlink.style.display === "none" ? "block" : "none";
            }
        }, 500);

        motor_controller.disable_motors();
    }

    unfreezeVideo() {
        this.paused = false;
        this.freezeButton.style.backgroundColor = "";
        this.freezeButton.classList.remove('stop_recording');
        this.freezeButton.classList.add('freeze');

        clearInterval(this.toggleInterval, 500);
        this.overlayElement.innerHTML = "";
        this.overlayElement.style.pointerEvents = "auto";
        this.overlayElement.style.display = "none";

        motor_controller.enable_motors();
    }

    toggleFreeze() {
        if( this.recording)
            return;

        if (!this.paused) {
            this.freezeVideo();
        } else {
            this.unfreezeVideo();
        }
    }



    handleDataAvailable(event) {
        console.log("data-available");
        if (event.data.size > 0) {
            console.log(this);
            this.recordedChunks.push(event.data);
            console.log(this.recordedChunks);
            this.download();
        } else {
            // …
        }
    }

    download() {
        const duration = Date.now() - this.startTime;

        const blob = new Blob(this.recordedChunks, {
            type: "video/webm",
        });
        //ysFixWebmDuration(blob, duration, function (fixedBlob) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            console.log(url, a);
            document.body.appendChild(a);
            a.style = "display: none";
            a.href = url;
            a.download = `Magnibot ${new Date().toLocaleTimeString()} ${new Date().toLocaleDateString()}.mp4`;
            a.click();
            window.URL.revokeObjectURL(url);
        //});

    }
}

const videoButton = document.getElementById("recordVideo");
const freezeButton = document.getElementById("button27");
const overlay6Element = document.querySelector(".overlay6");
const videoRecorder = new VideoRecorder(document.getElementById("renderTarget"), videoButton, freezeButton, overlay6Element);


const splitscreenVideoButton = document.getElementById("splitscreenRecord");
const splitscreenFreezeButton = document.getElementById("splitscreenFreeze");
const splitscreenOverlay = document.getElementById("splitscreenFreezeRecordOverlay");
const splitscreenVideoRecorder = new VideoRecorder(document.getElementById("splitScreen"), splitscreenVideoButton, splitscreenFreezeButton, splitscreenOverlay);