const VERTEX_SHADER = `
attribute vec2 a_position;
attribute vec2 a_texCoord;
uniform float u_scale;
uniform bool u_flipped;
uniform vec2 u_resolution;
varying vec2 vTextureCoord;
void main() {
   vec2 zeroToOne = a_position / u_resolution;
   vec2 zeroToTwo = zeroToOne * 2.0;
   vec2 clipSpace = zeroToTwo - 1.0;
   clipSpace.x *= u_scale;
   gl_Position = vec4(clipSpace * vec2(1, -1), 0, 1);
   gl_Position.x *= u_flipped ? -1.0 : 1.0;
   gl_Position.y *= u_flipped ? -1.0 : 1.0;
   vTextureCoord = a_texCoord;
}`;

const brightnessMin = -1.5;
const brightnessMax = 1.75;
const contrastMin = 1;
const contrastMax = 5.5;
const defaultContrast_A = 0.7;
const defaultContrast_B = 0.2;
const defaultContrast_C = 0.2;
const defaultContrast = 1;

const IMAGE_MESSAGE_SIZE = 32 * 4;

function lerp(a,b,t) {
    return (t*a) + (1-t)*b;
}

function clamp(val, min, max) {
    return Math.min(Math.max(val, min), max);
}

class CanvasManager {
    lastDraw = 0;
    paused = false;
    scale = 1;
    lastScale = 1;
    flipped = false;

    zoomMode = "none";

    contrast_A = defaultContrast_A;
    contrast_B = defaultContrast_B;
    contrast_C = defaultContrast_C;
    contrast = defaultContrast;

    contrast_ALocation;
    contrast_BLocation;
    contrast_CLocation;
    contrastLocation;

    shaderIndex = 0;
    shader = FRAGMENT_SHADERS[0];

    glBuffers = {
        positionBuffer: undefined,
        textcoordBuffer: undefined,
        texture: undefined
    };

    constructor(camera, source, canvas, videoRecorder) {
        this.camera = camera;
        this.source = source;
        this.canvas = canvas;
        this.videoRecorder = videoRecorder;

        let offscreenCanvas = new OffscreenCanvas(1, IMAGE_MESSAGE_SIZE);
        this.offscreenCanvasContext = offscreenCanvas.getContext("2d", { alpha: false, antialias: false });
    }

    start() {
        let onload = (img) => {
            this.setup(img);
            this.requestFrame(img);
            this.loaded = true;
            this.source = img;
        };

        if (this.loaded) {
            this.setup(this.source);
            return;
        }

        if (this.source?.nodeName == "VIDEO") {
            input.addEventListener("loadedmetadata", () => onload(input))
        } else {
            let streamImage = new Image();
            streamImage.crossOrigin = "anonymous";
            streamImage.decoding = "sync";
            streamImage.fetchPriority = "high";
            streamImage.src = this.source;
            streamImage.onload = () => onload(streamImage);
        }
    }

    flip() {
        this.flipped = !this.flipped;
        this.updateShaderValues();
    }

    async fullZoomOut() {
        let scalerCrop = await (await fetch(`http://${document.location.host}:8080/fullZoomOut`)).text();
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.glBuffers.texcoordBuffer);
        let degrees = 0;
        //setInterval(() => this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(this.createUVs(degrees--)), this.gl.STATIC_DRAW), 16);
        const OFFSET = 0.2;
        const MIN = 0 + OFFSET;
        const MAX = 1 - OFFSET;
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(this.createUVs(-90, [MIN, MIN], [MAX, MIN], [MIN, MAX], [MAX, MAX])), this.gl.STATIC_DRAW);
        console.log(scalerCrop);
        
    }

    async returnZoom() {
        await fetch(`http://${document.location.host}:8080/returnZoom`);
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.glBuffers.texcoordBuffer);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(this.createUVs(-90)), this.gl.STATIC_DRAW);
    }

    setZoomScale(newScale) {
        this.lastScale = this.scale;
        this.scale = newScale;
        this.updateShaderValues();
    }

    loadSettings(magnibotSettings) {
        if (this.camera == "pi") {
            this.shaderIndex = magnibotSettings.shaderIndexPi;
        } else {
            this.shaderIndex = magnibotSettings.shaderIndex[1];
        }
        this.shader = FRAGMENT_SHADERS[this.shaderIndex];

        const settings = magnibotSettings.canvasSettings ?? {};
        const cameraSettings = this.camera in settings ? settings[this.camera] : {};
        if(cameraSettings.contrast != undefined) this.contrast = cameraSettings.contrast;
        if(cameraSettings.brightness != undefined) this.contrast_A = cameraSettings.brightness;
        if(cameraSettings.brightnessB != undefined) this.contrast_B = cameraSettings.brightnessB;
        if(cameraSettings.brightnessC != undefined) this.contrast_C = cameraSettings.brightnessC;

        if(this.gl != undefined)
            this.updateShaderValues()
    }

    requestFrame(image, time = 0) {
        let deltaTime = (time - this.lastDraw) / 1000;
        if (!this.videoRecorder.paused) {
            this.render(image, deltaTime);
        }

        this.lastDraw = time;
        window.requestAnimationFrame((time) => this.requestFrame(image, time));
    }

    render(image, deltaTime) {
        if(image.width == 1 || image.height == 1) { //if its a data frame decode it and dont render
            this.offscreenCanvasContext.drawImage(image, 0, 0);
            let pixel = this.offscreenCanvasContext.getImageData(0, 0, 1, IMAGE_MESSAGE_SIZE);
            let reducer = (prev, current, i) => {
                if(i % 4 == 0) {
                    prev.push(current)
                }
                return prev;
            };

            let adder = (prev, current) => prev + current;

            let bytes1 = pixel.data.subarray(IMAGE_MESSAGE_SIZE * 0, IMAGE_MESSAGE_SIZE * 1).reduce(reducer, []).reduce(adder);
            let scalerCropWidth = pixel.data.subarray(IMAGE_MESSAGE_SIZE * 1, IMAGE_MESSAGE_SIZE * 2).reduce(reducer, []).reduce(adder);
            let bytes3 = pixel.data.subarray(IMAGE_MESSAGE_SIZE * 2, IMAGE_MESSAGE_SIZE * 3).reduce(reducer, []).reduce(adder);
            let maxWidth = pixel.data.subarray(IMAGE_MESSAGE_SIZE * 3, IMAGE_MESSAGE_SIZE * 4).reduce(reducer, []).reduce(adder);

            this.setZoomScale(1 - ((scalerCropWidth - maxWidth) / scalerCropWidth))
            return;
        }

        /*
        if(this.zoomMode == "zoomIn") {
            this.scale = Math.max(this.scale - (0.35 * deltaTime), 0.1)
            this.updateShaderValues();
        } else if(this.zoomMode == "zoomOut") {
            this.scale = Math.min(this.scale + (0.35 * deltaTime), 3.15)
            this.updateShaderValues();
        }
        */
        this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.RGBA, this.gl.RGBA, this.gl.UNSIGNED_BYTE, image);
        //this.gl.generateMipmap(gl.TEXTURE_2D);
        //this.gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST_MIPMAP_LINEAR);
        let primitiveType = this.gl.TRIANGLES;
        let offset = 0;
        let count = 6;
        this.gl.drawArrays(primitiveType, offset, count);
    }

    setup(image) {
        this.gl = this.canvas.getContext("webgl");
        if (!this.gl) {
            return;
        }

        let program = webglUtils.createProgramFromSources(this.gl, [VERTEX_SHADER, this.shader.shader]);
        let positionLocation = this.gl.getAttribLocation(program, "a_position");
        let texcoordLocation = this.gl.getAttribLocation(program, "a_texCoord");

        this.glBuffers.positionBuffer = this.gl.createBuffer();
        webglUtils.resizeCanvasToDisplaySize(this.canvas);
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.glBuffers.positionBuffer);
        this.setRectangle(this.gl, 0, 0, this.gl.canvas.width, this.gl.canvas.height);
        this.glBuffers.texcoordBuffer = this.gl.createBuffer();
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.glBuffers.texcoordBuffer);
        this.gl.bufferData(this.gl.ARRAY_BUFFER, new Float32Array(this.createUVs(this.camera == "pi" ? -90 : 0)), this.gl.STATIC_DRAW);
        // Create a texture.
        this.glBuffers.texture = this.gl.createTexture();
        this.gl.bindTexture(this.gl.TEXTURE_2D, this.glBuffers.texture);
        // Set the parameters so we can render any size image.
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_S, this.gl.CLAMP_TO_EDGE);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_WRAP_T, this.gl.CLAMP_TO_EDGE);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.LINEAR);
        this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MAG_FILTER, this.gl.LINEAR);

        this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.RGBA, this.gl.RGBA, this.gl.UNSIGNED_BYTE, image);
        //this.gl.generateMipmap(this.gl.TEXTURE_2D);
        //this.gl.texParameteri(this.gl.TEXTURE_2D, this.gl.TEXTURE_MIN_FILTER, this.gl.NEAREST_MIPMAP_LINEAR);

        let resolutionLocation = this.gl.getUniformLocation(program, "u_resolution");
        
        this.scaleLocation = this.gl.getUniformLocation(program, "u_scale");
        this.flippedLocation = this.gl.getUniformLocation(program, "u_flipped");
        this.contrast_ALocation = this.gl.getUniformLocation(program, "u_ContrastA");
        this.contrast_BLocation = this.gl.getUniformLocation(program, "u_ContrastB");
        this.contrast_CLocation = this.gl.getUniformLocation(program, "u_ContrastC");
        this.contrastLocation = this.gl.getUniformLocation(program, "contrast");

        this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
        this.gl.clearColor(0, 0, 0, 0);
        this.gl.clear(this.gl.COLOR_BUFFER_BIT);
        this.gl.useProgram(program);
        this.gl.enableVertexAttribArray(positionLocation);
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.glBuffers.positionBuffer);

        let size = 2;          // 2 components per iteration
        let type = this.gl.FLOAT;   // the data is 32bit floats
        let normalize = false; // don't normalize the data
        let stride = 0;        // 0 = move forward size * sizeof(type) each iteration to get the next position
        let offset = 0;        // start at the beginning of the buffer
        this.gl.vertexAttribPointer(positionLocation, size, type, normalize, stride, offset);

        this.gl.enableVertexAttribArray(texcoordLocation);
        this.gl.bindBuffer(this.gl.ARRAY_BUFFER, this.glBuffers.texcoordBuffer);
        size = 2;          // 2 components per iteration
        type = this.gl.FLOAT;   // the data is 32bit floats
        normalize = false; // don't normalize the data
        stride = 0;        // 0 = move forward size * sizeof(type) each iteration to get the next position
        offset = 0;        // start at the beginning of the buffer
        this.gl.vertexAttribPointer(texcoordLocation, size, type, normalize, stride, offset);
        this.gl.uniform2f(resolutionLocation, this.gl.canvas.width, this.gl.canvas.height);
        this.updateShaderValues();

        let primitiveType = this.gl.TRIANGLES;
        offset = 0;
        let count = 6;
        this.gl.drawArrays(primitiveType, offset, count);
    }

    setRectangle(gl, x, y, width, height) {
        var x1 = x;
        var x2 = x + width;
        var y1 = y;
        var y2 = y + height;
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
            x1, y1,
            x2, y1,
            x1, y2,
            x1, y2,
            x2, y1,
            x2, y2,
        ]), gl.STATIC_DRAW);
    }

    updateShaderValues() {
        if (this.contrast_ALocation != undefined) {
            this.gl.uniform1f(this.contrast_ALocation, this.contrast_A); //a cannot go below b otherwise it inverts
        }
        if (this.contrast_BLocation != undefined) {
            this.gl.uniform1f(this.contrast_BLocation, this.contrast_B);
        }
        if (this.contrast_CLocation != undefined) {
            this.gl.uniform1f(this.contrast_CLocation, this.contrast_C);
        }
        if (this.contrastLocation != undefined) {
            this.gl.uniform1f(this.contrastLocation, this.contrast);
        }
        if (this.flippedLocation != undefined) {
            this.gl.uniform1f(this.flippedLocation, this.flipped);
        }
        if (this.scaleLocation != undefined) {
            if(this.scale > 0.95 && this.scale <= 1) {
                this.scale = 1;
            }
            this.gl.uniform1f(this.scaleLocation, this.scale);
            /*
            if(this.scale > 1) {
                //let scaleValue = 1 - ((this.scale-1) / (16/9*2));
                //let scaleValue = (1 - ((this.scale-1) / (3.15-1))) * (16/9*2);
                let scaleValue = lerp(0.5625, 1, (this.scale-1) / (3.15-1));
                console.log(this.scale, (this.scale-1) / (3.15-1))
                this.gl.uniform1f(this.scaleLocation, scaleValue);
            } else {
                this.gl.uniform1f(this.scaleLocation, 1);
            }
            */
        }
    }

    updateOpenGLCanvas() {
        this.gl.deleteBuffer(this.glBuffers.positionBuffer);
        this.gl.deleteBuffer(this.glBuffers.texcoordBuffer);
        this.gl.deleteTexture(this.glBuffers.texture);

        shader = FRAGMENT_SHADERS[shaderIndex];
        this.start();
    }

    cycleShaders() {
        this.gl.deleteBuffer(this.glBuffers.positionBuffer);
        this.gl.deleteBuffer(this.glBuffers.texcoordBuffer);
        this.gl.deleteTexture(this.glBuffers.texture);
        this.shaderIndex = (this.shaderIndex + 1) % FRAGMENT_SHADERS.length;
        let newFragmentShader = FRAGMENT_SHADERS[this.shaderIndex];
        // If current color was deactivated in settings, load the next active color
        var loopCounter = 0;
        while (newFragmentShader.enabled == false) {
            // Limit the loop around to one cycle than breakout
            if (loopCounter >= FRAGMENT_SHADERS.length)
                break;
            this.shaderIndex = (this.shaderIndex + 1) % FRAGMENT_SHADERS.length;
            newFragmentShader = FRAGMENT_SHADERS[this.shaderIndex];
            loopCounter++;
            console.log("Max loops: " + loopCounter);
        }

        if (this.camera == "pi") {
            socket.emit('set_shaderIndexPi', { shaderIndex: this.shaderIndex });
        } else {
            socket.emit('set_shaderIndex', { shaderIndex: this.shaderIndex });
        }

        this.shader = newFragmentShader;
        this.start();
        saveUISettings();
    }

    resetContrast() {
        this.contrast = defaultContrast;
        socket.emit('set_canvasSetting', { camera: this.camera, setting: "contrast", value: this.contrast });
        this.updateShaderValues();
    }
    increaseContrast() {
        this.contrast = clamp(this.contrast + 0.075, contrastMin, contrastMax);
        socket.emit('set_canvasSetting', { camera: this.camera, setting: "contrast", value: this.contrast });
        this.updateShaderValues();
    }
    decreaseContrast() {
        this.contrast = clamp(this.contrast - 0.075, contrastMin, contrastMax);
        socket.emit('set_canvasSetting', { camera: this.camera, setting: "contrast", value: this.contrast });
        this.updateShaderValues();
    }
    resetBrightness() {
        this.contrast_A = defaultContrast_A;
        this.contrast_C = defaultContrast_C;
        socket.emit('set_canvasSetting', { camera: this.camera, setting: "brightness", value: this.contrast });
        socket.emit('set_canvasSetting', { camera: this.camera, setting: "brightnessC", value: this.contrast_C });
        this.updateShaderValues();
    }
    increaseBrightness() {
        if (FRAGMENT_SHADERS[this.shaderIndex].usesCAsBrightness) {
            this.contrast_C = clamp(this.contrast_C - 0.015, brightnessMin, brightnessMax);
            socket.emit('set_canvasSetting', { camera: this.camera, setting: "brightnessC", value: this.contrast_C });
        } else {
            this.contrast_A = clamp(this.contrast_A + 0.015, this.contrast_B + 0.01, contrastMax);
            socket.emit('set_canvasSetting', { camera: this.camera, setting: "brightness", value: this.contrast_A });
        }
        this.updateShaderValues();
    }
    decreaseBrightness() {
        if (FRAGMENT_SHADERS[this.shaderIndex].usesCAsBrightness) {
            this.contrast_C = clamp(this.contrast_C + 0.015, brightnessMin, brightnessMax);
            socket.emit('set_canvasSetting', { camera: this.camera, setting: "brightnessC", value: this.contrast_C });
        } else {
            this.contrast_A = clamp(this.contrast_A - 0.015, this.contrast_B + 0.01, contrastMax);
            socket.emit('set_canvasSetting', { camera: this.camera, setting: "brightness", value: this.contrast_A });
        }
        this.updateShaderValues();
    }

    createUVs(rotation, topLeft = [0, 0], topRight = [1, 0], bottomLeft = [0, 1], bottomRight = [1, 1]) {
        rotation = (Math.PI / 180) * rotation;
        let rotate = (x, y) => [(x*Math.cos(rotation) - y*Math.sin(rotation)) + 0.5, (x*Math.sin(rotation) + y*Math.cos(rotation)) + 0.5];

        const TOP_LEFT = rotate(topLeft[0]-0.5, topLeft[1]-0.5);
        const TOP_RIGHT = rotate(topRight[0]-0.5, topRight[1]-0.5);
        const BOTTOM_LEFT = rotate(bottomLeft[0]-0.5, bottomLeft[1]-0.5);
        const BOTTOM_RIGHT = rotate(bottomRight[0]-0.5, bottomRight[1]-0.5);

        return [
            ...TOP_LEFT,
            ...TOP_RIGHT,
            ...BOTTOM_LEFT,
            ...BOTTOM_LEFT,
            ...TOP_RIGHT,
            ...BOTTOM_RIGHT,
        ]
    }
}