class SplitScreenManager {

    inSplitscreenMode = false;

    constructor(camera, canvasManager, mainCanvasManager) {
        this.camera = camera;
        this.controls = document.getElementById("splitScreenControls");
        this.mainCanvas = document.getElementById("renderTarget");
        this.canvas = document.getElementById("splitScreen");
        this.canvasManager = canvasManager;
        this.mainCanvasManager = mainCanvasManager;
        this.motorController = new MotorControllerNew(camera);

        this.buttons = {
            up: document.getElementById("split-up"),
            down: document.getElementById("split-down"),
            left: document.getElementById("split-left"),
            right: document.getElementById("split-right"),

            zoomIn: document.getElementById("split-zoomin"),
            zoomOut: document.getElementById("split-zoomout"),

            toggleColor: document.getElementById("split-toggleColor"),
            cameraOptions: document.getElementById("split-cameraOptions"),
            settings: document.getElementById("split-settings"),
            savePicture: document.getElementById("splitscreenSavePicture"),
        }

        this.bindButtons();
    }

    toggle() {
        if (this.inSplitscreenMode) {
            this.finish()
        } else {
            this.start();
        }
    }

    start() {
        this.controls.style.display = "block";
        this.inSplitscreenMode = true;
        this.canvas.style.display = "block";
        this.canvas.style.height = "50%";
            
        this.mainCanvas.style.height = "50%";
        this.canvasManager.start();
        this.mainCanvasManager.start();   
    }

    finish() {
        this.controls.style.display = "none";
        this.inSplitscreenMode = false;
        this.image = undefined;
        this.canvas.style.display = "none";
        this.mainCanvas.style.height = "100%";
        this.mainCanvasManager.start();
    }

    ocr() {
        let ocrWindow = window.open("/ocr", '_blank');
        ocrWindow.focus();

        window.addEventListener('message', (e) => {
            if (e.data == 'inited') {
                ocrWindow.postMessage(this.camera == "pi" ? "ocr" : "ocr-main", '*');
            }
        });
    }

    bindButtons() {
        this.buttons.toggleColor.onclick = () => this.canvasManager.cycleShaders(true);

        this.buttons.zoomIn.onpointerdown = () => this.motorController.zoom_in();
        this.buttons.zoomIn.onpointerup = () => this.motorController.zoom_stop();

        this.buttons.zoomOut.onpointerdown = () => this.motorController.zoom_out();
        this.buttons.zoomOut.onpointerup = () => this.motorController.zoom_stop();

        //left and right are flipped originally for some reason so these are too now
        this.buttons.left.onpointerdown = () => this.motorController.right();
        this.buttons.left.onpointerup = () => this.motorController.stopHorizontal();

        this.buttons.right.onpointerdown = () => this.motorController.left();
        this.buttons.right.onpointerup = () => this.motorController.stopHorizontal();

        this.buttons.up.onpointerdown = () => this.motorController.up();
        this.buttons.up.onpointerup = () => this.motorController.stopVertical();

        this.buttons.down.onpointerdown = () => this.motorController.down();
        this.buttons.down.onpointerup = () => this.motorController.stopVertical();

        this.buttons.savePicture.onpointerdown = () => {
            if (this.camera == "pi") {
                let image = this.canvas.toDataURL("image/png").replace("image/png", "image/octet-stream");
                window.location.href = image;
            } else {
                takeSnapshot();
            }
        }

        let camDropdown = document.getElementById('splitscreen-camera-dropdown');
        this.buttons.cameraOptions.onpointerup = function (e) {
            if (camDropdown.style.display == 'inline') {
                camDropdown.style.display = 'none';
            } else {
                camDropdown.dataset.openedBy = "splitscreen";
                let rect = e.target.getBoundingClientRect();
                camDropdown.style.backgroundColor = 'white';
                camDropdown.style.position = 'absolute';
                camDropdown.style.display = 'inline';
                camDropdown.style.left = rect.left + 'px';
                camDropdown.style.width = rect.width + 'px';
                camDropdown.style.height = (rect.height * 3) + 'px';

                let camDropdownRect = camDropdown.getBoundingClientRect();
                camDropdown.style.top = (rect.top - camDropdownRect.height) + 'px';
            }
        };

        
        let settingsOverlay = document.getElementById('splitscreenSettingsOverlay');
        this.buttons.settings.onpointerup = () => {
            if (settingsOverlay.style.display == 'inline') {
                settingsOverlay.style.display = 'none';
            } else {
                settingsOverlay.style.display = 'inline';
            }
        }
    }
}

let isSplitscreenButtonsVisible = false;
function toggleSplitscreenControls() {
    if (isSplitscreenButtonsVisible) {
        $(".innerControls").css("display", "none");
        $("#splitScreenControls").css("height", "15%");
        $(".toggleMenuSplitscreen").css("background-image", "url(\"/images/down.png\")");
        $(".toggleSplitscreenMenu").css("height", "100%");
        isSplitscreenButtonsVisible = false;
        $(".overlay1").css("display", "none");
        $(".overlay4").css("display", "none");
        document.getElementById('splitscreen-camera-dropdown').style.display = 'none';
    } else {
        $(".innerControls").css("display", "table");
        $("#splitScreenControls").css("height", "25%");
        $(".toggleMenuSplitscreen").css("background-image", "url(\"/images/up.png\")");
        $(".toggleSplitscreenMenu").css("height", "50%");
        isSplitscreenButtonsVisible = true;
    }
}