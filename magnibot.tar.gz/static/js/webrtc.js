// Initialize Janus library.
Janus.init({
  // Turn on debug logs in the browser console.
  debug: false,

  // Configure Janus to use standard browser APIs internally.
  // dependencies: Janus.useDefaultDependencies(),
});

// Establish a WebSockets connection to the server.
const janus = new Janus({
  // Specify the URL of the Janus server’s WebSockets endpoint.
  server: `ws://${window.location.hostname}/janus/ws`,

  // Callback function if the client connects successfully.
  success: attachUStreamerPlugin,

  // Callback function if the client fails to connect.
  error: console.error,
});
async function playWebrtcVideo(video, shouldRetryWithMuting = true) {
      // const video = this.elements.video;

      try {
        await video.play();
      } catch (error) {
        // The `AbortError` error typically means that something had
        // canceled the video initialization while it was in-flight. In our
        // case, this usually originates from another, simultaneous play
        // request that got stopped (which then stops all other play
        // requests via this error). We can’t do anything about this here,
        // so we abort and leave it to that other (succeeding) play request
        // to continue handling the issue.
        if (error.name === "AbortError") {
          console.debug(error);
          throw error;
        }

        // The `NotAllowedError` means that playing video is not allowed,
        // most likely because the UserAgent has blocked audio or video
        // autoplay. If this happens, the browser usually stops the video
        // element altogether (and not just the audio). If only audio was
        // blocked, we can try to recover video by muting the stream.
        // Overall, we only attempt this once, to avoid an infinite
        // recursion.
        if (error.name === "NotAllowedError" && shouldRetryWithMuting) {
          console.debug(error);
          video.muted = true;
          return playWebrtcVideo(video,false);
        }

        // For any other errors, the only thing we can do is log them.
        console.error("Failed to play WebRTC media: " + error);
        throw error;
      }
    }

async function enableWebrtcStreamTrack(video,mediaStreamTrack) {
      console.log("enableWebrtcStreamTrack");
      // const video = this.elements.video;
      if (!video.srcObject) {
        // Lazy-initialize the media stream. (See comment in
        // `connectedCallback`.)
        video.srcObject = new MediaStream();
      }
      const stream = video.srcObject;

      // Ensure that the stream doesn't contain multiple tracks of the same
      // kind (i.e., multiple audio or video tracks).
      // For example, if an additional new video track is being added, first
      // remove the old video track.
      for (const track of stream.getTracks()) {
        if (
          track.kind === mediaStreamTrack.kind &&
          track.id !== mediaStreamTrack.id
        ) {
          stream.removeTrack(track);
        }
      }

      // Note: If the specified track is already in the stream's track set,
      // the addTrack method has no effect.
      // https://developer.mozilla.org/en-US/docs/Web/API/MediaStream/addTrack
      stream.addTrack(mediaStreamTrack);

      console.log("addTrack");
      // We only proceed switching to WebRTC if we have at least a video
      // track. We don’t want to switch yet if the only thing we have is an
      // audio track.
      // It’s also important that we hold off on displaying the WebRTC
      // stream until the video playback has started, to ensure a smooth
      // visual transition of the remote screen without any flickering or
      // interruption.
      if (mediaStreamTrack.kind === "video") {
        // We optimistically unmute before we start the playback, because we
        // cannot tell ahead of time whether audio is blocked by the
        // UserAgent.
        console.log("video");
        video.muted = false;
        try {
          await playWebrtcVideo(video);
        } catch {
          console.log("play failed");
          return;
        }

      }
      else{
        console.log("audio");
      }
    }
    async function disableWebrtcStreamTrack(video, mediaStreamTrack) {
      if (!video.srcObject) {
        return;
      }
      const stream = video.srcObject;
      stream.removeTrack(mediaStreamTrack);
      if (stream.getVideoTracks().length === 0) {
        video.pause();
        // this.enableMjpeg();
      }
    }



function attachUStreamerPlugin() {
  let watchRequestRetryExpiryTimestamp = null;
  let janusPluginHandle = null;
  // Instruct the server to attach the µStreamer Janus plugin.
  janus.attach({
    // Qualifier of the plugin.
    plugin: "janus.plugin.ustreamer",

    // Callback function, for when the server attached the plugin
    // successfully.
    success: function (pluginHandle) {
      janusPluginHandle = pluginHandle;
      watchRequestRetryExpiryTimestamp = Date.now() + (60 * 1000);
      // Instruct the µStreamer Janus plugin to initiate streaming.
      janusPluginHandle.send({ message: { request: "watch", params: {audio: true} } });
    },

    // Callback function if the server fails to attach the plugin.
    error: console.error,

    // Callback function for processing messages from the Janus server.
    onmessage: function (msg, jsep) {
  // `503` indicates that the plugin was not initialized yet and therefore
  // isn’t ready to stream yet. We retry the watch request, until either the
  // H.264 stream is available, or the watch request timeout has been
  // reached.
  if (
    msg.error_code === 503 &&
    watchRequestRetryExpiryTimestamp > Date.now()
  ) {
    janusPluginHandle.send({
      message: { request: "watch", params: { audio: true } },
    });
    return;
  }
  if (!jsep) {
    return;
  }
  janusPluginHandle.createAnswer({
    jsep: jsep,
    // Disable sending audio and video (which would otherwise default to
    // `true`), to prevent the browser from presenting a permission dialog
    // to the user.
    media: { audioSend: false, videoSend: false },
    success: function (jsep) {
      // Send back the generated webRTC response. We technically don’t have
      // to send a `start` request for starting the stream, as the plugin
      // already starts streaming after the `watch` request. However,
      // without a `start` request, the server complains about the request
      // being malformed, which we want to avoid out of “good practice”.
      janusPluginHandle.send({
        message: { request: "start" },
        jsep: jsep,
      });
    },
    error: function (error) {
      console.error("Failed to create JSEP answer: " + error);
    },
  });
},

    // Callback function, for when a media stream arrives.
    onremotetrack: async function (mediaStreamTrack, mediaId, isAdded) {
      if (isAdded) {
        const videoElement = document.getElementById("video_preview");
        await enableWebrtcStreamTrack(videoElement,mediaStreamTrack);
      }
      else{
        await disableWebrtcStreamTrack(videoElement,mediaStreamTrack);

      }
    },
  });
}