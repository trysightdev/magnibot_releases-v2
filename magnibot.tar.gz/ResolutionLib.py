import os
import subprocess
USTREAMER_FILE = 'ustreamer.service'
USTREAMER_MJPEG_OPTS = "--host 127.0.0.1 --port 8001 --encoder hw --format jpeg --resolution {resolution} --desired-fps {fps} --quality 100 --persistent"
USTREAMER_H264_OPTS = "--host 127.0.0.1 --port 8001 --encoder hw --format jpeg --resolution {resolution} --desired-fps {fps} --quality 100 --persistent --h264-sink tinypilot::ustreamer::h264 --h264-sink-mode 777 --h264-sink-rm --h264-bitrate 20000"
class ResolutionLib:
    def __init__(self):
        pass
    def create_ustreamer_service_file(self, video_format, resolution, fps):
        if video_format == 'H264':
            ustreamer_cmd = "ustreamer {}".format(USTREAMER_H264_OPTS.format(resolution=resolution, fps=fps))
        else:
            ustreamer_cmd = "ustreamer {}".format(USTREAMER_MJPEG_OPTS.format(resolution=resolution, fps=fps))
        service_content = f"""\
[Unit]
Description=uStreamer - Lightweight, optimized video encoder
After=syslog.target network.target
[Service]
User={os.getlogin()}
ExecStartPre=/bin/sleep 15
#ExecStartPre=/bin/sleep 25
ExecStart={ustreamer_cmd}
Restart=always
[Install]
WantedBy=multi-user.target
"""
        with open(USTREAMER_FILE, 'w') as f:
            f.write(service_content)
        # Copy the service file to the systemd directory
        os.system(f"sudo cp -f {USTREAMER_FILE} /etc/systemd/system/")
        os.system("sudo systemctl daemon-reload")
        os.system("sudo systemctl stop ustreamer")
        print("ustreamer Restarted")
    def setup_ustreamer(self, video_format, resolution, fps):
        self.create_ustreamer_service_file(video_format, resolution, fps)
# Example usage:
# res_lib = ResolutionLib()
# res_lib.setup_ustreamer('H264', '1280x720', '30')
